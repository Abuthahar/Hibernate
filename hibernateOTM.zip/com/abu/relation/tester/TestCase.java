package com.abu.relation.tester;

import com.abu.relation.dao.PetDAO;
import com.abu.relation.dto.OwnerDTO;

import com.abu.relation.dto.PetDTO;

public class TestCase {

	public static void main(String[] args) {
		
		OwnerDTO ownerDTO =new OwnerDTO();
		ownerDTO.setName("James");
		
		PetDTO dto =new PetDTO();
		dto.setName("Tom");
		dto.setType("cat");
		dto.setOwner(ownerDTO);
		
		PetDAO dao = new PetDAO();
		dao.savePet(dto);
		PetDTO res = dao.selectPet(1);
		System.out.println(res);
		
		dao.updatePet(1);
		PetDTO res1 = dao.selectPet(1);
		System.out.println(res1);
		dao.deletePet(1);
	}
}
