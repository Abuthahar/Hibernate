package com.abu.relation.tester;

import java.util.ArrayList;
import java.util.List;

import com.abu.relation.dao.OwnerDAO;
import com.abu.relation.dao.PetDAO;
import com.abu.relation.dto.OwnerDTO;
import com.abu.relation.dto.PetDTO;

public class TestBi {
	
	public static void main(String[] args) {
		OwnerDTO dto = new OwnerDTO();
		dto.setName("John");
		
		PetDTO p1 = new PetDTO();
		p1.setName("Tom");
		p1.setType("cat");
		p1.setOwner(dto);
		
		PetDTO p2 = new PetDTO();
		p2.setName("Spike");
		p2.setType("dog");
		p2.setOwner(dto);
		
		PetDTO p3 = new PetDTO();
		p3.setName("Tony");
		p3.setType("dog");
		p3.setOwner(dto);
		
		List<PetDTO> plst = new ArrayList<PetDTO>();
		plst.add(p1);
		plst.add(p2);
		plst.add(p3);
		
		dto.setPet(plst);
		
		OwnerDAO dao = new OwnerDAO();
		dao.savePet(dto);
		OwnerDTO res = dao.selectPet(1);
		System.out.println(res);
		dao.updatePet(1);
		dao.deletePet(1);
		
	}

}
