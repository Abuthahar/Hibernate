package com.abu.relation.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.abu.relation.dto.OwnerDTO;
import com.abu.relation.dto.OwnerDTO;
import com.hibernate.demo.Hibernateutil;

public class OwnerDAO {
	
	Session session;
	Transaction transaction;

	public void savePet(OwnerDTO dto) {
		try {
			session = Hibernateutil.getFactory().openSession();
			transaction = session.beginTransaction();
			session.save(dto);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}

	}

	public OwnerDTO selectPet(int primarykey) {
		OwnerDTO dto=null;
		try {
			session = Hibernateutil.getFactory().openSession();
			System.out.println(session);
			transaction = session.beginTransaction();
			dto = session.get(OwnerDTO.class, new Integer(primarykey));
			System.out.println(dto);
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
		return dto;
	}
	
	  public void updatePet(int primarykey){
		  try {
			session = Hibernateutil.getFactory().openSession();
			  transaction= session.beginTransaction();
			  OwnerDTO dto = session.get(OwnerDTO.class, new Integer(primarykey));
			  dto.setName("John");
			  session.update(dto);
			  transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
			if (session != null)
				session.close();
		}
	  }
	  
	  public void deletePet(int primarykey){
		  try {
			session = Hibernateutil.getFactory().openSession();
			  transaction = session.beginTransaction();
			  OwnerDTO dto = session.get(OwnerDTO.class, new Integer(primarykey));
			  session.delete(dto);
			  transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
			if (session != null)
				session.close();
		}
	  }


}
