package com.abu.hql.dao;

import org.hibernate.*;

import com.abu.hql.dto.PGDTO;
import com.hibernate.demo.Hibernateutil;

public class PGDAO {

	SessionFactory factory = null;
	Session session = null;
	Transaction transaction = null;

	public void savePg(PGDTO pgdto) {
		try {
			factory = Hibernateutil.getFactory();
			session = factory.openSession();
			transaction = session.beginTransaction();
			session.save(pgdto);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
	}
}
