package com.abu.hql.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import java.util.*;
import com.abu.hql.dto.PGDTO;
import com.hibernate.demo.Hibernateutil;

public class PGHQLDAO {
	String hql = "update PGDTO set rent = ? where name = ?";
	String selhql = "select name from PGDTO  where sharing = ?";
	String delhql = "delete from PGDTO where name = ?";

	public void updatePG(int rent, String name) {
		SessionFactory factory = null;
		Session session = null;
		Transaction transaction = null;

		try {
			factory = Hibernateutil.getFactory();
			session = factory.openSession();
			transaction = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setInteger(0, rent);
			query.setString(1, name);
//			query.setParameter(0, rent);
			/*query.setParameter(name, hql);
			query.setParameter(rent, hql);*/
			query.executeUpdate();
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
	}

	public List<PGDTO> readPG(int sharing) {
		List<PGDTO> list = null;
		SessionFactory factory = null;
		Session session = null;

		try {
			factory = Hibernateutil.getFactory();
			session = factory.openSession();
			Query query = session.createQuery(selhql);
			query.setInteger(0, sharing);
			//query.setParameter(sharing, sharing);
			list = query.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
		return list;
	}

	public Object readResultPG(int sharing) {
		Object object = null;
		SessionFactory factory = null;
		Session session = null;
		Transaction transaction = null;

		try {
			factory = Hibernateutil.getFactory();
			session = factory.openSession();
			Query query = session.createQuery(selhql);
			query.setInteger(0, sharing);
			object = query.uniqueResult();
		} catch (HibernateException e) {
			
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
		return object;
	}

	public void deletPeG(String name) {
		SessionFactory factory = null;
		Session session = null;
		Transaction transaction = null;

		try {
			factory = Hibernateutil.getFactory();
			session = factory.openSession();
			transaction = session.beginTransaction();
			Query query = session.createQuery(delhql);
			query.setString(0, name);
			query.executeUpdate();
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
	}

}
