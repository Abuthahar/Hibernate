package com.abu.hql.tester;

import java.util.Scanner;

import com.abu.hql.dao.PGHQLDAO;
import com.abu.hql.dto.PGDTO;

public class ConditonTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
			System.out.println("1.Create");
			System.out.println("2.Update");
			System.out.println("3.Select");
			System.out.println("4.Select_Result");
			System.out.println("5.Delete");
			System.out.println("Enter Your Choice");
			int i = sc.nextInt();
			while (i <= 5) {
				if (i == 1) {
					PGTest test = new PGTest();
					test.create();
					System.out.println("Create Operation done Successfully");
					break;
				} else if (i == 2) {
					PGHQLDAO dao = new PGHQLDAO();
					System.out.println("Enter the rent");
					int rent = sc.nextInt();
					System.out.println("Enter the name");
					String name = sc.next();
					dao.updatePG(rent, name);
					System.out.println("Update Operation done Successfully");
					break;
				} else if (i == 3) {
					PGHQLDAO dao = new PGHQLDAO();
					System.out.println("Enter the Sharing");
					int sharing = sc.nextInt();
					java.util.List<PGDTO> list = dao.readPG(sharing);
					System.out.println(list);
					System.out.println("Select Operation done Successfully");
					break;
				} else if (i == 4) {
					PGHQLDAO dao = new PGHQLDAO();
					System.out.println("Enter the Sharing");
					int sharing = sc.nextInt();
					Object list1 = dao.readResultPG(sharing);
					System.out.println(list1);
					System.out.println("Select Operation done Successfully");
					break;
				} else if (i == 5) {
					PGHQLDAO dao = new PGHQLDAO();
					System.out.println("Enter the name");
					String name = sc.next();
					dao.deletPeG(name);
					System.out.println("Delete Operation done Successfully");
					break;
				}
				System.out.println("Sorry...! :( Invalid Selection");
			}
			

	}
}
