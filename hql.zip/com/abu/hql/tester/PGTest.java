package com.abu.hql.tester;

import java.util.Scanner;

import com.abu.hql.dao.PGDAO;
import com.abu.hql.dto.PGDTO;

public class PGTest {
	public void create(){
	PGDTO pgdto = new PGDTO();
	Scanner sc = new Scanner(System.in);
	System.out.println("enter the name ");
	String name = sc.nextLine();
	System.out.println("enter the no of rooms ");
	int no = sc.nextInt();
	System.out.println("enter the rent ");
	int rent = sc.nextInt();
	System.out.println("enter the sharing ");
	int share = sc.nextInt();
	
	pgdto.setName(name);
	pgdto.setNoOfRoom(no);
	pgdto.setRent(rent);
	pgdto.setSharing(share);
	
	PGDAO pgdao = new PGDAO();
	pgdao.savePg(pgdto);
	}

}
