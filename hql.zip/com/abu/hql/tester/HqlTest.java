package com.abu.hql.tester;

import com.abu.hql.dao.PGHQLDAO;
import com.abu.hql.dto.PGDTO;
public class HqlTest {
public static void main(String[] args) {
	
	PGHQLDAO dao = new PGHQLDAO();
	dao.updatePG(4500, "SaiRam");
	java.util.List<PGDTO> list = dao.readPG(3);
	System.out.println(list);
	
	Object list1 = dao.readResultPG(4);
	System.out.println("4"+list1);
	//dao.deletPeG();
}
}
