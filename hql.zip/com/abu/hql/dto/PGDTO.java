package com.abu.hql.dto;

import java.io.Serializable;
import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="pg_table")
public class PGDTO implements Serializable {

	public PGDTO() {
		System.out.println(this.getClass().getSimpleName() + "Done");
	}

	@Id
	@GenericGenerator(name="auto",strategy="increment")
	@GeneratedValue(generator="auto")
	@Column(name="room_no")
	private int roomNo;
	private int sharing;
	private int noOfRoom;
	private String name;
	private int rent;

	
	public int getSharing() {
		return sharing;
	}

	public void setSharing(int sharing) {
		this.sharing = sharing;
	}

	public int getNoOfRoom() {
		return noOfRoom;
	}

	public void setNoOfRoom(int noOfRoom) {
		this.noOfRoom = noOfRoom;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRent() {
		return rent;
	}

	public void setRent(int rent) {
		this.rent = rent;
	}

	public int getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}

	@Override
	public String toString() {
		return "PGDTO [roomNo=" + roomNo + ", sharing=" + sharing + ", noOfRoom=" + noOfRoom + ", name=" + name
				+ ", rent=" + rent + "]";
	}
	
}
