package com.abu.hibernate.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.abu.hibernate.dto.UniverseDTO;
import com.hibernate.demo.Hibernateutil;

public class UniverseHQL {
	String hql = "update UniverseDTO set size = :size where nameOfPlanet = :name";
	String selhq = "select universe  from UniverseDTO universe where position=:pos";
	String selhql = "select nameOfPlanet from UniverseDTO universe";
	String delhql = "delete from UniverseDTO where noOfMoon = :moon";

	public void updateUniverse(double size, String nameOfPlanet) {
		SessionFactory factory = null;
		Session session = null;
		Transaction transaction = null;

		try {
			factory = Hibernateutil.getFactory();
			session = factory.openSession();
			transaction = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setParameter("size", size);
			query.setParameter("name", nameOfPlanet);
			query.executeUpdate();
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
	}

	public List<UniverseDTO> readUniverse() {
		List<UniverseDTO> list = null;
		SessionFactory factory = null;
		Session session = null;

		try {
			factory = Hibernateutil.getFactory();
			session = factory.openSession();
			Query query = session.createQuery(selhql);
			list = query.list();
			Object[] obj = list.toArray();
			for (Object arr : obj) {
				System.out.println(arr);
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
		return list;
	}

	public Object readResultUniverse(int position) {
		Object object = null;
		SessionFactory factory = null;
		Session session = null;

		try {
			factory = Hibernateutil.getFactory();
			session = factory.openSession();
			Query query = session.createQuery(selhq);
			query.setParameter("pos", position);
			object = query.uniqueResult();
		} catch (HibernateException e) {

			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
		return object;
	}

	public void deletUniverse(int noOfMoon) {
		SessionFactory factory = null;
		Session session = null;
		Transaction transaction = null;

		try {
			factory = Hibernateutil.getFactory();
			session = factory.openSession();
			transaction = session.beginTransaction();
			Query query = session.createQuery(delhql);
			query.setParameter("moon", noOfMoon);
			query.executeUpdate();
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
	}

}
