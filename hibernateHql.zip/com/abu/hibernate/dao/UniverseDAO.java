package com.abu.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.abu.hibernate.dto.UniverseDTO;
import com.hibernate.demo.Hibernateutil;

public class UniverseDAO {
	SessionFactory factory = null;
	Session session = null;
	Transaction transaction = null;

	public void saveUniverse(UniverseDTO dto) {
		try {
			factory = Hibernateutil.getFactory();
			session = factory.openSession();
			transaction = session.beginTransaction();
			session.save(dto);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
	}
	
	public void updateUniverse(int primarykey) {
		try {
			factory = Hibernateutil.getFactory();
			session = factory.openSession();
			transaction = session.beginTransaction();
			UniverseDTO dto = session.get(UniverseDTO.class,new Integer(primarykey));
			dto.setNameOfPlanet("earth");
			session.update(dto);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
	}
	
	UniverseDTO dto;
	
	public UniverseDTO readUniverse(int primarykey) {
		try {
			factory = Hibernateutil.getFactory();
			session = factory.openSession();
			session.load(UniverseDTO.class,new Integer(primarykey));
		} catch (HibernateException e) {
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
		return dto;
	}
	
	public void deleteUniverse(int primarykey) {
		try {
			factory = Hibernateutil.getFactory();
			session = factory.openSession();
			transaction = session.beginTransaction();
			UniverseDTO dto =session.load(UniverseDTO.class,new Integer(primarykey));
			session.delete(dto);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
	}
	
}


