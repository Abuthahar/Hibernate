package com.abu.hibernate.dto;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="universe_table")
public class UniverseDTO implements Serializable {
	public UniverseDTO() {
		System.out.println(this.getClass().getSimpleName());
	}
	@Id
	@GenericGenerator(name="auto",strategy="increment")
	@GeneratedValue(generator="auto")
	private int position;
	private String nameOfPlanet;
	private int noOfMoon;
	private double size;
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	public String getNameOfPlanet() {
		return nameOfPlanet;
	}
	public void setNameOfPlanet(String nameOfPlanet) {
		this.nameOfPlanet = nameOfPlanet;
	}
	public int getNoOfMoon() {
		return noOfMoon;
	}
	public void setNoOfMoon(int noOfMoon) {
		this.noOfMoon = noOfMoon;
	}
	public double getSize() {
		return size;
	}
	public void setSize(double size) {
		this.size = size;
	}
	@Override
	public String toString() {
		return "UniverseDTO [position=" + position + ", nameOfPlanet=" + nameOfPlanet + ", noOfMoon=" + noOfMoon
				+ ", size=" + size + "]";
	}
	
	
}
