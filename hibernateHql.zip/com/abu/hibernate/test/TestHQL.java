package com.abu.hibernate.test;

import java.util.List;

import com.abu.hibernate.dao.UniverseHQL;
import com.abu.hibernate.dto.UniverseDTO;

public class TestHQL {
public static void main(String[] args) {
	
	UniverseHQL hql = new UniverseHQL();
	hql.updateUniverse(2535, "earth");
	
	UniverseDTO dto=(UniverseDTO) hql.readResultUniverse(1);
	System.out.println(dto);
	List<UniverseDTO> list =hql.readUniverse();
	
//	hql.deletUniverse(0);
}
}
