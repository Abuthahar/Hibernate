package com.abu.hibernate.test;

import com.abu.hibernate.dao.UniverseDAO;
import com.abu.hibernate.dto.UniverseDTO;

public class Test {
public static void main(String[] args) {
	UniverseDTO dto = new UniverseDTO();
	/*dto.setNameOfPlanet("venus");
	dto.setNoOfMoon(0);
	dto.setSize(3524);
	*/
	UniverseDAO dao = new UniverseDAO();
//	dao.saveUniverse(dto);
	
	/*dao.updateUniverse(1);
	UniverseDTO dto2 =dao.readUniverse(1);
	System.out.println(dto);*/
	
	dao.deleteUniverse(1);
}
}
