package com.jspiders.final_project.mvc.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jspiders.final_project.mvc.ClientDTO.ClientDTO;
import com.jspiders.final_project.mvc.model.service.BussinessLogic;

@WebServlet("/reg")
public class RegisterController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String fn = req.getParameter("fn");
		String ln = req.getParameter("ln");
		String email = req.getParameter("email");
		String pwd = req.getParameter("pwd");
		String gender = req.getParameter("gen");
		ClientDTO dto = new ClientDTO();
		dto.setFirst_name(fn);
		dto.setLast_name(ln);
		dto.setEmail_id(email);
		dto.setPassword(pwd);
		dto.setGender(gender);

		Date now = new Date();
		dto.setCreated_time_stamp(now);
		BussinessLogic bl = new BussinessLogic();
		bl.register(dto);
	}

}
