package com.jspiders.final_project.mvc.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.DatatypeConverter;

public class HashGenerator {

	public String getHash(String password) {
		// RegisterDTO dto=new RegisterDTO();
		// String password= dto.getPassword();
		byte[] hash = null;
		Date d = new Date();
		// System.out.println(d);
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateFormat = df.format(d);
		System.out.println(dateFormat);
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			hash = digest.digest((password + dateFormat).getBytes("UTF-8"));

			// for (int i = 0; i < hash.length; i++) {
			// System.out.print(hash[i]);
			// }
		} catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bytesToHex(hash);
	}

	public String bytesToHex(byte[] hash) {

		return DatatypeConverter.printHexBinary(hash);

	}

}
