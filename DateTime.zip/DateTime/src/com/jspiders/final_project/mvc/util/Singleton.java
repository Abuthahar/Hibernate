package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Singleton {
	private static final Singleton single;
	private Connection con;
	static {
		single = new Singleton();
	}

	private Singleton() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/servlet", "root", "tiger");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void finalize() throws Throwable {

		if (con != null) {
			con.close();
			con = null;
		}
	}

	public static Singleton getObject() {
		return single;
	}

	public Connection getConnection() {
		return con;
	}

}
