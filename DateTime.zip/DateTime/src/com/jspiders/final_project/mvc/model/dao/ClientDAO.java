package com.jspiders.final_project.mvc.model.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jspiders.final_project.mvc.ClientDTO.ClientDTO;
import com.jspiders.final_project.mvc.util.*;
import com.jspiders.hibernate.HibernateUtil;

public class ClientDAO {

	Transaction trn = null;
	Session session = null;

	public boolean saveClientInfo(ClientDTO dto) {
		try {
			SessionFactory factory = HibernateUtil.getSessionFactory();
			session = factory.openSession();
			trn = session.beginTransaction();
			session.save(dto);
			trn.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			trn.rollback();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return false;
	}
}
