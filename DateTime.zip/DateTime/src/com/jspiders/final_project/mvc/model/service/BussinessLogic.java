package com.jspiders.final_project.mvc.model.service;

import com.jspiders.final_project.mvc.ClientDTO.ClientDTO;
import com.jspiders.final_project.mvc.controller.RegisterController;
import com.jspiders.final_project.mvc.model.dao.ClientDAO;
import com.jspiders.final_project.mvc.util.HashGenerator;

public class BussinessLogic {

	public boolean register(ClientDTO dto) {
		ClientDAO dao = new ClientDAO();
		dao.saveClientInfo(dto);
		HashGenerator generator = new HashGenerator();
		String password = dto.getPassword();
		String encryptedPassword = generator.getHash(password);
		dto.setPassword(encryptedPassword);
		boolean result = dao.saveClientInfo(dto);
		return result;
	}

}
