package com.abu.criteria.test;

import java.util.List;

import com.abu.criteria.dao.SportDAO;
import com.abu.criteria.dto.SportDTO;

public class Test {
public static void main(String[] args) {
	SportDTO dto = new SportDTO();
	dto.setName("football");
	dto.setNoOfPlayer(11);
	dto.setType("outdoor");
	SportDAO dao = new SportDAO();
//	dao.save(dto);
	 List<SportDTO> list = dao.read();
	 for (SportDTO sportDTO : list) {
		 System.out.println(sportDTO.getNoOfPlayer() + sportDTO.getName());
	}
	
	/*List<Object[]> pro = dao.pro();
	for (Object[] o : pro) {
		 System.out.println(o[0]);
		 System.out.println(o[1]);
	
	}*/
}
}
