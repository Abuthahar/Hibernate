package com.abu.criteria.dao;

import java.util.List;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.PropertyProjection;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

import com.abu.criteria.dto.SportDTO;

public class SportDAO {
	
	public void save(SportDTO dto) {
		try {
			Configuration cfg = new Configuration();
			Session session = cfg.configure().buildSessionFactory().openSession();
			Transaction transaction = session.beginTransaction();
			session.save(dto);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
	}
	List<SportDTO> list ;
	public List<SportDTO> read() {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Criteria criteria = session.createCriteria(SportDTO.class);
		criteria.add(Restrictions.gt("noOfPlayer",7));
		list=criteria.list();
		 
		return list;
	}
	List<Object[]> list1 ;
	public List<Object[]> pro() {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Criteria criteria = session.createCriteria(SportDTO.class);
		 PropertyProjection p = Projections.property("name");
		 PropertyProjection p1 = Projections.property("noOfPlayer");
		 ProjectionList pl = Projections.projectionList();
		 pl.add(p);
		 pl.add(pl);
		 criteria.setProjection(pl);
		return list1;
	}
}
